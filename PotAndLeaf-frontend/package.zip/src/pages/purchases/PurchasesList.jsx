import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { CheckCircleIcon, PlusIcon } from '@heroicons/react/24/outline';
import api from '../../lib/api';
import { useAuth } from '../../context/AuthContext';
import { Badge, Button, Card, Spinner } from '../../components/ui';
import { formatCurrency, formatDate } from '../../lib/format';

const STATUS_TABS = [
  { value: '', label: 'All' },
  { value: 'draft', label: 'Draft' },
  { value: 'confirmed', label: 'Confirmed' },
  { value: 'cancelled', label: 'Cancelled' },
];

const statusTone = { draft: 'inactive', confirmed: 'active', cancelled: 'blocked' };

export default function PurchasesList() {
  const { activeCompany, can } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [status, setStatus] = useState('');

  const { data, isLoading, isError } = useQuery({
    queryKey: ['purchases', activeCompany?.id, status],
    queryFn: () => api.get('/purchases', { params: { status } }).then((r) => r.data),
    enabled: Boolean(activeCompany),
    keepPreviousData: true,
  });

  const confirmMutation = useMutation({
    mutationFn: (id) => api.post(`/purchases/${id}/confirm`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['purchases'] });
      queryClient.invalidateQueries({ queryKey: ['inventory'] });
    },
  });

  const rows = data?.data ?? [];

  return (
    <div className="space-y-5 p-4 sm:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-lg font-semibold">Purchases</h1>
          <p className="text-sm text-muted">GST purchase entries. Confirming a draft posts stock to the ledger.</p>
        </div>
        {can('purchases.create') && (
          <Link to="/purchases/new">
            <Button size="sm">
              <PlusIcon className="size-4" /> New purchase
            </Button>
          </Link>
        )}
      </div>

      <div className="flex gap-1 border-b border-line">
        {STATUS_TABS.map((tab) => (
          <button
            key={tab.value}
            onClick={() => setStatus(tab.value)}
            className={
              'border-b-2 px-3 py-2 text-sm transition-colors ' +
              (status === tab.value
                ? 'border-leaf font-medium text-leaf'
                : 'border-transparent text-muted hover:text-ink')
            }
          >
            {tab.label}
          </button>
        ))}
      </div>

      <Card className="overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center py-16">
            <Spinner className="size-6" />
          </div>
        ) : isError ? (
          <div className="px-4 py-12 text-center text-sm text-muted">Couldn't load purchases.</div>
        ) : rows.length === 0 ? (
          <div className="px-4 py-16 text-center">
            <p className="text-sm font-medium">No purchases here</p>
            <p className="mt-1 text-sm text-muted">Record a purchase to bring stock into the godown.</p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left font-mono text-[10px] uppercase tracking-wider text-muted">
                <th className="px-4 py-2.5 font-medium">No.</th>
                <th className="px-4 py-2.5 font-medium">Date</th>
                <th className="px-4 py-2.5 font-medium">Supplier</th>
                <th className="px-4 py-2.5 font-medium">Invoice</th>
                <th className="px-4 py-2.5 text-right font-medium">Total</th>
                <th className="px-4 py-2.5 font-medium">Status</th>
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {rows.map((p) => (
                <tr key={p.id} className="border-b border-line/60 last:border-0 hover:bg-paper/60">
                  <td className="tnum px-4 py-2.5 text-xs">{p.purchase_no}</td>
                  <td className="px-4 py-2.5 text-muted">{formatDate(p.purchase_date)}</td>
                  <td className="px-4 py-2.5 font-medium">{p.supplier?.name ?? '—'}</td>
                  <td className="tnum px-4 py-2.5 text-xs text-muted">{p.invoice_no || '—'}</td>
                  <td className="tnum px-4 py-2.5 text-right">{formatCurrency(p.grand_total)}</td>
                  <td className="px-4 py-2.5">
                    <Badge tone={statusTone[p.status] ?? 'default'}>{p.status}</Badge>
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center justify-end gap-2">
                      {p.can?.update && (
                        <Button variant="outline" size="sm" onClick={() => navigate(`/purchases/${p.id}/edit`)}>
                          Edit
                        </Button>
                      )}
                      {p.can?.confirm && (
                        <Button
                          size="sm"
                          onClick={() => confirmMutation.mutate(p.id)}
                          disabled={confirmMutation.isPending}
                        >
                          <CheckCircleIcon className="size-4" /> Confirm
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}
